﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigitalCalculator;

namespace GoldStock
{
    class Program
    {

        static void Main(string[] args)
        {
            ICustomerdigitalwallet custWallet = new GoldCalculator();
            Console.WriteLine(ConstCustomerInput.cutomerTransDetails);
            string transDetails = Console.ReadLine();
            switch (transDetails.ToUpper())
            {
                case "PURCHASE":
                    {
                        try
                        {
                            string continuePurchase = decision.YES.ToString();
                            while (!(continuePurchase.ToUpper() == decision.NO.ToString()))
                            {
                                Console.Write(ConstCustomerInput.customerID);
                                int custId = int.Parse(Console.ReadLine());
                                string purchaseDetails = custWallet.CustomerPurchase(custId, GetPurchaseModelDetails());
                                Console.WriteLine(purchaseDetails);
                                Console.WriteLine(ConstCustomerInput.lineSeparator);
                                Console.WriteLine(ConstCustomerInput.contPurchase);
                                continuePurchase = Console.ReadLine();
                            }

                            Console.WriteLine(ConstCustomerInput.sellDetails);
                            if (Console.ReadLine().ToUpper() == decision.YES.ToString())
                            {
                                goto case "SELL";
                            }
                            else
                            {
                                Console.WriteLine(ConstCustomerInput.commMess);
                            }
                        }
                        catch
                        {
                            throw new Exception(ConstCustomerInput.exceptionMessage);
                        }

                        break;
                    }

                case "SELL":
                    {

                        Console.Write(ConstCustomerInput.customerID);
                        int custId = int.Parse(Console.ReadLine());
                        string saleDetails = custWallet.CustomerSale(custId, GetSaleModelDetails());
                        Console.WriteLine(saleDetails);

                        break;
                    }
            }
           
            Console.ReadLine();
        }

        /// <summary>
        /// Generate Purchase Model Details.
        /// </summary>
        /// <returns>PurchaseModel</returns>
        private static PurchaseModel GetPurchaseModelDetails()
        {
            PurchaseModel purchasemodel = new PurchaseModel();
            Console.Write(ConstCustomerInput.goldRate);
            string goldrate = Console.ReadLine();
            purchasemodel.GoldRate = double.Parse(goldrate);
            Console.WriteLine(ConstCustomerInput.purchaseDetails);
            Console.Write(ConstCustomerInput.amountToInvest);
            string amt = Console.ReadLine();
            purchasemodel.Amount = double.Parse(amt);
            return purchasemodel;
        }

        /// <summary>
        /// Generate Sale Model Details
        /// </summary>
        /// <returns>SaleModel</returns>
        private static SaleModel GetSaleModelDetails()
        {
            SaleModel sale = new SaleModel();
            Console.Write(ConstCustomerInput.goldRate);
            string goldrate = Console.ReadLine();
            sale.GoldRate = double.Parse(goldrate);
            Console.WriteLine(ConstCustomerInput.sellDettails);
            Console.Write(ConstCustomerInput.goldToSell);
            string goldtosell = Console.ReadLine();
            sale.goldtoSell = double.Parse(goldtosell);
            return sale;
        }

        
    }
}
