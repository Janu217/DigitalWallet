﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class ConstCustomerInput
    {
        public const string cutomerTransDetails = "Do you want to Purchase Gold/Sell Item? [purchase/Sell]";
        public const string customerID = "Enter customer id to purchase the items : ";
        public const string contPurchase = "Do you want to continue your purhcase ? [yes/no]";
        public const string sellDetails = "Do you want to Sell Gold?[Yes / No]";
        public const string goldRate = "Enter Today's Gold Rate : ";
        public const string purchaseDetails = "Enter items details to purchase : ";
        public const string sellDettails = "Enter items details to Sale : ";
        public const string goldToSell = "Enter decided Gold to sell (grams): ";
        public const string amountToInvest = "Enter Amount to Invest : ";
        public const string commMess = "Thanks for Visiting!";
        public const string exceptionMessage = "Something went wrong! please try again!";
        public const string lineSeparator = "=========================================================";
    }

    public enum decision
    { 
        YES,
        NO
    }

    public enum purchaseSale
    {
        purchase,
        Sell
    }
}
