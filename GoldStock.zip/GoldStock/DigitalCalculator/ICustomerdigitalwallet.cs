﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public interface ICustomerdigitalwallet
    {
        string CustomerSale(int custId, SaleModel salem);
        string CustomerPurchase(int custId, PurchaseModel pm);
    }
}
