﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class PurchaseModel
    {
         public Items Item { get; set; } 
         public DateTime? PurchaseDate { get; set; }
         public int PurchaseID { get; set; }  
         public double Amount  { get; set; }
         public double GoldRate { get; set; }
    }
}
