﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class CustomerSalesDetails
    {
        public CustomerSalesDetails()
        {
            Cust = new Customer();
            Sales = new List<Sales>();
        }

        public Customer Cust;
        public List<Sales> Sales;

        /// <summary>
        /// Generate Customer Sale Details
        /// </summary>
        /// <param name="c">Customer</param>
        /// <param name="sales">Sale</param>
        /// <returns>CustomerSalesDetails</returns>
        public static CustomerSalesDetails GenerateSalesDetails(Customer c, Sales sales)
        {
            CustomerSalesDetails cd = new CustomerSalesDetails();
            cd.Cust = c;
            cd.Sales.Add(sales);
            return cd;
        }
    }
}
