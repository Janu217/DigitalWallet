﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class Customer
    {
        public int CutomerId { get; set; }
        public String CustomerName { get; set; }

        /// <summary>
        /// Customer Details
        /// </summary>
        /// <param name="custId"></param>
        /// <returns>Customer</returns>
        public static Customer CreateCustomer(int custId)
        {
            Customer c = new Customer();
            c.CutomerId = custId;
            return c;
        }
    }
}
