﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class Sales
    {
        public const int commisionCharges = 100;

        public Sales()
        {
            Cust = new Customer();
        }
        public Customer Cust { get; set; }
        public int SaleID { get; set; }
        public double goldtoSell { get; set; }
        public double GoldRate { get; set; }
        public double totalAccumGoldTillDate { get; set; }
        public double totalInvestedAmtTillDate { get; set; }
        public bool isProfitorLoss { get; set; }
        public double profitorlossDetails { get; set; }

        /// <summary>
        /// Create sales details
        /// </summary>
        /// <param name="c"></param>
        /// <param name="salesm"></param>
        /// <returns>Calculated sales value.</returns>
        public static Sales CreateSales(Customer c, SaleModel salesm)
        {
            Sales sales = null;
            if (salesm.goldtoSell < salesm.totalAccumGoldTillDate)
            {
                sales = new Sales();
                sales.Cust = c;
                sales.goldtoSell = salesm.goldtoSell;
                sales.totalAccumGoldTillDate = salesm.totalAccumGoldTillDate;
                sales.totalInvestedAmtTillDate = salesm.totalInvestedAmtTillDate;
                double profitamt = calculatesellingProfitPrice(salesm.goldtoSell, salesm.GoldRate, sales.totalAccumGoldTillDate, sales.totalInvestedAmtTillDate);
                sales.isProfitorLoss = isprofitorloss(profitamt);
                sales.profitorlossDetails = profitamt;
            }
  
            return sales;
        }

        /// <summary>
        /// Calculate total selling price includeing commision charges.
        /// </summary>
        /// <param name="goldtoSell"></param>
        /// <param name="goldRate"></param>
        /// <param name="investedGold"></param>
        /// <param name="investedGoldamt"></param>
        /// <returns></returns>
        private static double calculatesellingProfitPrice(double goldtoSell, double goldRate, double investedGold, double investedGoldamt)
        {
            double totalcalculation = goldRate * goldtoSell;
            double sellingcommcharges = goldtoSell * commisionCharges;
            double totalSellamt = totalcalculation - sellingcommcharges;
            double profitamt = (investedGoldamt * goldtoSell) / investedGold;
            return totalSellamt - profitamt;
        }

        /// <summary>
        /// Deside is it profit or loss to sell the items.
        /// </summary>
        /// <param name="profitorlossamt"></param>
        /// <returns></returns>
        private static bool isprofitorloss(double profitorlossamt)
        {
            return true ? profitorlossamt > 0 : false;
        }

    }
}
