﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class PurchaseFacade
    {
        /// <summary>
        /// This method create Purchase order details for newly added customer.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        public static CustomerPurchaseDetails Create_Customer_Purchase_Order(int c, PurchaseModel p)
        {
            var cust = Customer.CreateCustomer(c);
            var purchase = Purchase.CreatePurchase(cust, p);
            CustomerPurchaseDetails cs = new CustomerPurchaseDetails();
            cs.Cust = cust;
            cs.Purc.Add(purchase);
            return cs;
        }

        /// <summary>
        /// This method create purchase order for already inserted customer.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        public static CustomerPurchaseDetails Create_Purchase_Order(Customer c, PurchaseModel p)
        {
            var purchase = Purchase.CreatePurchase(c, p);

            CustomerPurchaseDetails cs = new CustomerPurchaseDetails();
            cs.Cust = c;
            cs.Purc.Add(purchase);
            return cs;
        }

    }

}
