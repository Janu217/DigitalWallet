﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class SaleFacade
    {
        /// <summary>
        /// This method creates Sale order details.
        /// </summary>
        /// <param name="c"></param>
        /// <param name="salem"></param>
        /// <returns></returns>
        public static CustomerSalesDetails Create_Customer_Sale_Order(int c, SaleModel salem)
        {
            var cust = Customer.CreateCustomer(c);
            var sales = Sales.CreateSales(cust, salem);

            CustomerSalesDetails cs = new CustomerSalesDetails();
            cs.Cust = cust;
            cs.Sales.Add(sales);
            return cs;
        }
    }
}
