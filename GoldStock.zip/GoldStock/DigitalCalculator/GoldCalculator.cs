﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class GoldCalculator : ICustomerdigitalwallet
    {
        public static Dictionary<int, CustomerPurchaseDetails> custpurchase = new Dictionary<int, CustomerPurchaseDetails>();
        public static Dictionary<int, CustomerSalesDetails> custSales = new Dictionary<int, CustomerSalesDetails>();

        /// <summary>
        /// Customer Sale Details are processed.
        /// </summary>
        /// <param name="custId"></param>
        /// <param name="sale"></param>
        /// <returns>Sale Details</returns>
        public string CustomerSale(int custId, SaleModel sale)
        {
            string saleDetails;
            if (!(custpurchase.ContainsKey(custId)))
            {
                return saleDetails = "There is no investement found for selected customer!";
            }
           
           var customerPurchaseDetails = custpurchase[custId].Purc;
                      
                sale.totalInvestedAmtTillDate = customerPurchaseDetails.Sum(x => x.investedAmt);
                sale.totalAccumGoldTillDate = customerPurchaseDetails.Sum(x => x.investedGold);
        
            var sales_order = SaleFacade.Create_Customer_Sale_Order(custId, sale);
            custSales.Add(custId, sales_order);
            
            if (sales_order.Sales[0] == null)
            {
                saleDetails = "Gold to Sell is greater then Accumulated Gold";
            }
            else
            {
                string decision = sales_order.Sales[0].isProfitorLoss == true ? "Profit" : "Loss";
                saleDetails = string.Format("you will get {0} of total Rs. {1}", decision, Math.Round(sales_order.Sales[0].profitorlossDetails));
            }
           
             return saleDetails;


        }

        /// <summary>
        /// Customer purchase details are processed
        /// </summary>
        /// <param name="custId"></param>
        /// <param name="pm"></param>
        /// <returns>Purchase Details</returns>
        public string CustomerPurchase(int custId, PurchaseModel pm)
        {
            if (!custpurchase.ContainsKey(custId))
            {
                Console.WriteLine("Customer not exists to purchase the items!");
                var purchase_order = PurchaseFacade.Create_Customer_Purchase_Order(custId, pm);
                 custpurchase.Add(custId, purchase_order);
                 string PurchaseDetails = string.Format("Customer purchase details added successfully! Invested amount including GST = {0}, Invested Gold (grams) = {1}", purchase_order.Purc[0].investedAmt, purchase_order.Purc[0].investedGold);
                 return PurchaseDetails;              

            }
            else
            {
                var purchase_order = PurchaseFacade.Create_Purchase_Order(custpurchase[custId].Cust, pm);
                custpurchase[custId].Purc.Add(purchase_order.Purc[0]);
                //custpurchase.Add(custId, purchase_order);
                string purchaseDetails = string.Format("Customer purchase details added successfully; Invested amount including GST= {0}, Invested Gold (grams) = {1}", purchase_order.Purc[0].investedAmt, purchase_order.Purc[0].investedGold);
                return purchaseDetails;
            }

            

        }

      
    }
}
