﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class SaleModel
    {
        public Items Item { get; set; }
        public DateTime? SaleDateDate { get; set; }
        public int SaleID { get; set; }
        public double goldtoSell { get; set; }
        public double GoldRate { get; set; }
        public double totalAccumGoldTillDate { get; set; }
        public double totalInvestedAmtTillDate { get; set; }
    }
}
