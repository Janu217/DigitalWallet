﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class Purchase
    {
        public const double StartAmount=0;
        public const double EndAmount=20000;
        public const double GSTValue = 0.05;

        public Purchase()
        {
            Cust = new Customer();
        }
        public Customer Cust { get; set; }
        public int PurchaseID { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public double Amount { get; set; }
        public Items Item { get; set; }
        public double goldrate { get; set; }
        public double investedAmt { get; set; }
        public double investedGold { get; set; }

        /// <summary>
        /// Create Purchase details for selected Customer
        /// </summary>
        /// <param name="c"></param>
        /// <param name="pm"></param>
        /// <returns>Purchase Details</returns>
        public static Purchase CreatePurchase(Customer c, PurchaseModel pm)
        {
           
            Purchase p = null;
            if (pm.Amount > StartAmount && pm.Amount <= EndAmount)
            {
                p = new Purchase();
                p.Cust = c;
                p.Item = pm.Item;
                p.PurchaseDate = pm.PurchaseDate;
                p.PurchaseID = pm.PurchaseID;
                p.Amount = pm.Amount;
                p.goldrate = pm.GoldRate;
                p.investedAmt = calculateGSTinvamt(pm.Amount);
                p.investedGold = calculateGoldInv(pm.Amount, pm.GoldRate);
            }
            else
            {
                Console.WriteLine(string.Format("Please Enter amount between {0} and {1}",StartAmount, EndAmount));
                CreatePurchase(c, pm);
            }
         
            return p;
        }

     
        /// <summary>
        /// Caculate Investement amount includeing GST.
        /// </summary>
        /// <param name="investementAmt"></param>
        /// <returns>Total Invested Amount</returns>
        public static double calculateGSTinvamt(double investementAmt)
        {
            return Math.Round(investementAmt - (investementAmt * GSTValue),2);
        }

        /// <summary>
        /// Calculate total gold Investement.
        /// </summary>
        /// <param name="acutalinvsamt"></param>
        /// <param name="goldRate"></param>
        /// <returns></returns>
        private static double calculateGoldInv(double acutalinvsamt, double goldRate)
        {
            return Math.Round((acutalinvsamt / goldRate), 2);
        }
       
    }
}
