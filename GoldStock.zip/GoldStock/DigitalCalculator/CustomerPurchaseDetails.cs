﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalCalculator
{
    public class CustomerPurchaseDetails
    {
        public CustomerPurchaseDetails()
        {
            Cust = new Customer();
            Purc = new List<Purchase>();
        }

        public Customer Cust;
        public List<Purchase> Purc;

        /// <summary>
        /// Generate CustomerPurchase Details.
        /// </summary>
        /// <param name="c">Customer</param>
        /// <param name="p">Purchase</param>
        /// <returns>CustomerPurchase Details</returns>
        public static CustomerPurchaseDetails GeneratePurchaseDetails(Customer c, Purchase p)
        {
            CustomerPurchaseDetails cd = new CustomerPurchaseDetails();
            cd.Cust = c;
            cd.Purc.Add(p);
            return cd;
        }
    }
}
